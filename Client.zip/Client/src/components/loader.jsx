import React from 'react'

const loader = () => {
  return (
    <div>
      
    </div>
  )
}

export default loader
